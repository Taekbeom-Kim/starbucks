def distance(strand1, strand2):
	return

